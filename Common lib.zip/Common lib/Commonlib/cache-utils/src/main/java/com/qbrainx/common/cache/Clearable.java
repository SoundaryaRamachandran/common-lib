package com.qbrainx.common.cache;

public interface Clearable {

    void clear();
}
