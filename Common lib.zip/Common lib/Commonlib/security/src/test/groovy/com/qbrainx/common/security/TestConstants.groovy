package com.qbrainx.common.security

trait TestConstants {

    String BEARER_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwibmFtZSI6Ik5hbWUiLCJyb2xlcyI6WyJBRE1JTiJdLCJwcml2aWxlZ2VzIjpbIlRFU1RfQVBQX0FMTE9XRUQiXX0.Zd1E4P--lHLQ8f2H9obuEXPBjxTO8wcm5AwqBYnQlgY"

}
