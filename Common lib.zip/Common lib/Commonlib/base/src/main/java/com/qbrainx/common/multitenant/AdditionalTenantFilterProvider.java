package com.qbrainx.common.multitenant;

public interface AdditionalTenantFilterProvider {

  Long fetchAdditionalTenantId();

}
