package com.qbrainx.common.multitenant;

public enum AdditionalTenantProviderType {

  CONFIG, SERVICE

}
