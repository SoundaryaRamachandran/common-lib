package com.qbrainx.common.validation.methodvalidation;

public interface UserService {
    User getUser();
}
